/*
  Geometry.cpp
 
  Application of the "Composite" design pattern.
  Class Picture is derived from Shape which allows pictures
  to contain other pictures as well as simple shapes.

  Date: February 2017 / orjste
*/

#include <iostream>
#include <vector>
using namespace std;

/*
  Class Point
  Purpose:     Definition of class Point
*/
class Point {
        float xc,yc;      // x-y coordinates
public:
        Point(float newx=0, float newy=0){ xc=newx; yc=newy; }
        float x() const               { return xc; }
        float x(float newx)             { return xc = newx; }
        float y() const               { return yc; }
        float y(float newy)             { return yc = newy; }
        Point operator+(const Point& p) const {
                return Point(xc+p.xc, yc+p.yc);
        }

        void operator+=(const Point& p) {
                  xc += p.x();
                  yc += p.y();
        }
        void printOn(ostream& strm=cout) const;

};

ostream& operator<<(ostream& strm, const Point& p);


void Point::printOn(ostream& strm) const
{
        strm << '(' << xc << ',' << yc << ')';
}

ostream& operator<<(ostream& strm, const Point& p)
{
        p.printOn(strm);
        return strm;
}

//---------------------------------------------------------

/*
  Class Shape
  Purpose: Abstract base class for concrete shapes
*/


class Shape {
        Point org;      // origin
protected:
        void setOrg(Point &no) { org=no;}

public:
        Shape() {}
        Shape(const Point o) : org(o) { }  //origin
        virtual ~Shape() {}
        Point origin() const { return org;}
        virtual void move(const Point d) { org+=d; }
        // draw is pure virtual ==>  Shape abstract class
        virtual void draw() const =0; // pure virtual
};


//---------------------------------------------------------

/*
  Class Line
  Purpose:     Definition of class Line
*/

class Line: public Shape {
        Point endp;        // end point
public:
        Line(const Point a, const Point b);
        virtual ~Line() {}
        virtual void move(const Point d);
        virtual void draw() const;
};



Line::Line(const Point a, const Point b)
: Shape(a), endp(b)
{ }

void Line::move(const Point d)
{
        Shape::move(d);
        endp += d;
}

void Line::draw() const
{
        cout << "Line from " << origin() << " to "
                << endp << endl;
}

//---------------------------------------------------------

/*
  Class   Circle
  Purpose:     Definition of class Circle
*/

class Circle: public Shape {
        int rad;        // radius of circle
public:
        Circle(const Point c, int r) : Shape(c) { rad = r; }
        virtual ~Circle() {}
        virtual void draw() const;
};


void Circle::draw() const
{
        cout << "Circle with center " << origin()
                << " and radius " << rad << endl;
}

//---------------------------------------------------------

/*
  Class Triangle
  Purpose:     Definition of class Triangle
*/


class Triangle: public Shape {
        Point p2,p3;    // 2nd and 3rd vertices
public:
        Triangle (const Point a, const Point b, const Point c);
        virtual ~Triangle() {}
        virtual void move(const Point d);
        virtual void draw() const;
};


Triangle::Triangle (const Point a, const Point b, const Point c)
: Shape(a), p2(b), p3(c)
{ }

void Triangle::move(const Point d)
{
        Shape::move(d);   // move origin and tp
        p2 += d;
        p3 += d;
}

void Triangle::draw() const
{
        cout << "Triangle with corners " << origin()
             << ", " << p2 << " and " << p3 << endl;
}

//---------------------------------------------------------

/*
  Class Picture
  Purpose:  Definition of class Picture
*/

// Let's derive Picture from Shape and implement Shape's interface.
// This will enable us to treat a Picture to same way as a simple Shape

class Picture: public Shape {
        vector<Shape*> shapes; // pointers to shapes
        int n;                 // number of shapes in this Picture
public:
        Picture( )
        :n(0) { }  // constructor

        virtual ~Picture(){}// destructor
        void add(Shape&);                       // add Shape to Picture
        virtual void draw() const;              // draw picture;
        virtual void move(const Point d);
};


void Picture::add(Shape &t)
{
    ++n;
    shapes.push_back(&t);  // add pointer to Shape to Picture
}

void Picture::draw() const  // draw a Picture
{
        for (int i=0; i<shapes.size(); i++)
            shapes[i]->draw(); // let the objects draw themselves
}


void Picture::move(const Point d) {

        for (int i=0; i<n; i++)
            shapes[i]->move(d); // let the objects move themselves
}


//---------------------------------------------------------------------------

int main(int argc, char* argv[])
{
        Line li1(Point(10,20),Point(100,200));  // create a Line
        Circle c1(Point(100,200),100);         // create a Circle
        li1.draw();             // draw the line
        c1.draw();     // draw the circle

        Picture pic1;   // create a Picture
        pic1.add(li1);  // add the line to the picture
        pic1.add(c1);   // ..and the circle
        cout << "==>Picture 1:" << endl;
        pic1.draw(); cout << endl;      // draw the picture
        pic1.move(Point(-10,-5));  // move the picture
        cout << "==>Picture 1 moved (-10,-5):" << endl;
        pic1.draw(); cout << endl;      // draw the picture

        Triangle t1(Point(-10,0),Point(20,30),Point(40,60));
        Circle c2(Point(50,75),80);

        // define another picture
        Picture pic2;
        pic2.add(t1); // add t1 to the picture
        pic2.add(c2);  // ...and c2
        cout << "==>Picture 2" << endl;
        pic2.draw();   cout << endl;   // draw


        // define a big picture 
        Picture bigPicture;
        bigPicture.add(pic1); // add pic1 to the picture
        bigPicture.add(pic2);  // ...and pic2
        cout << "==>Big Picture " << endl;
        bigPicture.draw();   cout << endl;   // draw everything
        bigPicture.move(Point(5,-5)); // move bigPicture by (5,-5);
        cout << "==>Big Picture moved (5,-5):" << endl;
        bigPicture.draw(); cout << endl; // draw the moved bigPicture
      
        cout << "--- Completed ----------------" << endl;
       
        return 0;
}



