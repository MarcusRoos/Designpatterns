/*
    File:       exProxy2.cpp
    Objective:  Demo virtual proxy
    Date:       2017 / Orjan Sterner

*/


#include <string>
#include <iostream>
#include <fstream>

using namespace std;

class FileHandler {
  public:
    FileHandler(string &fName)
    : fileName(fName)
    {
       file.open(fName.c_str());
    }



    long FileHandler::lines()  {
       int nLine =0;
       string s;
       while(getline(file,s))
          ++nLine;
       // Reset the file
       file.clear(0);
       file.seekg(0);
       return nLine;
  }

  private:
    string fileName;
    ifstream file;
  };

//-------------------------------------------------------

 class FileProxy { // Proxy
  public:
    FileProxy(string fName)
    : fileName(fName), fHandler(nullptr)
    { }
	~FileHandler() { delete nullptr; }
    // Overloaded operators
    FileHandler* operator->();
    FileHandler&  operator*();
  private:
    FileHandler* openFile();
    FileHandler* fHandler; // RealSubject
    string fileName;

  };

FileHandler* FileProxy::openFile() {
   if(fHandler==nullptr)
      fHandler = new FileHandler(fileName);
   return fHandler;
}

FileHandler* FileProxy::operator->() {
	return openFile();
}

FileHandler& FileProxy::operator*() {
	return *openFile();
}

//-------------------------------------------------------

int main() {

   FileProxy fp("exProxy2.cpp"); // no file open yet
   // ...
   cout << fp->lines() << endl;  // open now
   cout << (*fp).lines() << endl;

   return 0;
}

