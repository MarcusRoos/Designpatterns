/*
    File:       exProxy.cpp
    Objective:  Demo virtual proxy
    Date:       2017 / Orjan Sterner

*/

#include <string>
#include <iostream>
#include <fstream>

using namespace std;


class AbstractFileHandler {
  public:
    virtual long lines() = 0;
};

// Real subject
class FileHandler : public AbstractFileHandler {
  public:
    FileHandler(string fName)
    :fileName(fName)
    {
       file.open(fName.c_str());
    }

    virtual long lines();
  private:
    string fileName;
    ifstream file;
  };

  long FileHandler::lines()  {
     int nLine =0;
     string s;
     while(getline(file,s))
        ++nLine;
     // Reset the file
     file.clear(0);
     file.seekg(0);
     return nLine;
  }


//--------------------------------------------------

 // Virtual proxy
 class FileProxy : public AbstractFileHandler {
  public:
    FileProxy(string fName)
    :fileName(fName),fHandler(NULL)
    {}

    virtual long lines();
  private:
    string fileName;
    FileHandler* fHandler; // RealSubject
  };


long FileProxy::lines() {   // Delegate to FileHandler
    if(fHandler == 0)
      fHandler = new FileHandler(fileName);
    return fHandler->lines();
}

//--------------------------------------------------

int main() {
    AbstractFileHandler *f = new FileProxy("exProxy.cpp");
    // doesn't open file yet

    cout << f->lines() << endl; // open now!
}

