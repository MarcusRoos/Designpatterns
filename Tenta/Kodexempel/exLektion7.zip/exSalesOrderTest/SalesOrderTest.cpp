/*
   File:        SalesOrderTest.cpp
   Objective:   Decorator example in DPE chapter 17.
   Created:     2007 / �rjan Sterner
*/


#include <iostream>
#include <string>

using namespace std;

class Component {
public:
    virtual void printTicket()=0;

};


// SalesTicket is our concrete component to be decorated
class SalesTicket : public Component {
public:
    SalesTicket(string text)
    :body(text)  { }

    virtual void printTicket() {
        cout << body << endl;
    }

private:
    string body;
};


// Abstract base class for decorators
class TicketDecorator : public Component {
public:
    TicketDecorator(Component *comp)
    :nextComp(comp) { }


    virtual void printTicket() {
    // Call prtTicket for the next component in chain
        if(nextComp!=NULL)
            nextComp->printTicket();
    }

private:
    Component *nextComp;
};


/* Concrete decorators
   Please note that the order of the calls in
   the implementations of prtTicket differs for the
   concrete decorators.
*/

class HeaderDecorator : public TicketDecorator {
public:
    HeaderDecorator(Component *comp)
    :TicketDecorator(comp) { }

    virtual void printTicket() {
        cout << "Header" << endl;
        TicketDecorator::printTicket();
    }
};


class FooterDecorator : public TicketDecorator {
public:
    FooterDecorator(Component *comp)
    :TicketDecorator(comp) { }

    virtual void printTicket() {
        TicketDecorator::printTicket();
        cout << "Footer" << endl;
    }
};



//------------------------------------------------------

class SalesOrder {
public:
    SalesOrder(string text)
    :bodyText(text)
    {
        // Build chain of decorators
        // firstComp points to the start of chain
        firstComp= new SalesTicket(bodyText);
        firstComp= new FooterDecorator(firstComp);
        firstComp= new HeaderDecorator(firstComp);
    }

    void printTicket() {
        firstComp->printTicket();
    }

private:
    Component *firstComp;
    string bodyText;
};


//------------------------------------------------------

class SalesOrderTest {
public:
    void run() {
        SalesOrder order("This is the ticket body text");
        order.printTicket();
    }
};


int main( ) {

    SalesOrderTest test;
    test.run();
    system("pause");
    return 0;
}