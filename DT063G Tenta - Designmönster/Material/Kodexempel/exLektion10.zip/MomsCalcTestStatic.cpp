/* File:    MomsCalculatorTestStatic.cpp
   Topic:   DP Singleton med lokal statisk varaibel
   Date:    feb 2016 / �rjan Sterner
*/

#include <iostream>
#include <cstdlib>
using namespace std;

const double MOMSPERCENTAGE = 25.0;

class MomsCalculator {
public:
    // Static function ==> invocation without instance
    static MomsCalculator* instance() {
		static MomsCalculator instObject{ MOMSPERCENTAGE };
        return &instObject;
    }

    double calcMoms(double price) {
        return momsPercentage * price / 100.0;
    }

    double getMomsPercent() {
        return momsPercentage;
    }


private:
    /* Construktor is non-public */
    MomsCalculator(double moms= MOMSPERCENTAGE)
    :momsPercentage(moms)
    { }

    // Accessed by static instance() ==> must be static
    static MomsCalculator *inst; // The instance
    double momsPercentage;

};


class MomsCalcTest {
public:
     void run() {
        double price;
        cout << "Price: ";
        cin >> price;
        while (price >0) {
           double moms = MomsCalculator::instance()->calcMoms(price);
           double percent = MomsCalculator::instance()->getMomsPercent();
           cout << "Moms: " << moms << " (" << percent << "%)" << endl;
           cout << "Price: ";
           cin >> price;
        }
     }
};

int main() {
    MomsCalcTest test;
    test.run();
    return 0;
}
