/* File:    TemplateMomsCalculatorTest.cpp
   Topic:   DP Singleton as a class template
   Date:    March 2016 / �rjan Sterner
*/

#include <iostream>
#include <cstdlib>
#include <memstat.h>
using namespace std;

const double MOMSPERCENTAGE = 25.0;


template <typename T>
class Singleton
{
public:

    /* Return a reference to the instance of the singleton class.
        Create the instance if necessary
    */
    static T* instance()
    {
        if (inst == nullptr) inst = new T;
        return inst;
    };


    /* Delete the singleton instance
    */
    static void destroy() {
        if (inst != nullptr) {
            delete inst;
            inst = nullptr;
        }
    }

private:

    // Non-public constructor.
    Singleton()
    { }

    virtual ~Singleton()
    { }

    // No copy constructor
    Singleton(const Singleton& source) = delete;

    static T* inst; // pointer to class instance
};

//static class member initialisation.
template <typename T> T* Singleton<T>::inst = nullptr;



class MomsCalculator {
    friend Singleton<MomsCalculator>;
public:

    ~MomsCalculator() {
        cout << "DEST" << endl;
    }

    double calcMoms(double price) {
        return momsPercentage * price / 100.0;
    }

    double getMomsPercent() {
        return momsPercentage;
    }


private:

    /* Construktor is non-public */
    MomsCalculator(double moms = MOMSPERCENTAGE)
        :momsPercentage(moms)
    { }

    double momsPercentage;

};

class MomsCalcTest {
public:
     void run() {
        double price;
        cout << "Price: ";
        cin >> price;
        while (price >0) {
           double moms = Singleton<MomsCalculator>::instance()->calcMoms(price);
           double percent = Singleton<MomsCalculator>::instance()->getMomsPercent();
           cout << "Moms: " << moms << " (" << percent << "%)" << endl;
           cout << "Price: ";
           cin >> price;
        }
     }
};

int main() {
    MomsCalcTest test;
    test.run();
    Singleton<MomsCalculator>::destroy(); // Deallocate the Singleton
    return 0;
}

