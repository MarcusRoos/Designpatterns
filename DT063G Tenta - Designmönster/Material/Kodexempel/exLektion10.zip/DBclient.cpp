/*
   File:   DBclient.cpp
   Topic:  Outline of using the Object Pool Pattern
           in the context of a remote database.
   Date:   January 2016 / �rjan Sterner
*/

#include <string>
#include <iostream>
#include <vector>

using namespace std;

//------------------------------------------------------------------------
class DataSet {
  // Dummy
};

//------------------------------------------------------------------------

/*
   ConnImpl
   En implementering av en fysisk uppkoppling mot databasen.
   Databasen klarar bara ett begr�nsat antal samtidiga uppkopplingar.
   En uppkoppling �r 'state-less' och kan �teranv�ndas.
*/

class ConnImpl {
public:
    DataSet* doQuery(string qStr, DataSet *ds) {
        return nullptr;   // Dummy
    }
};

//------------------------------------------------------------------------

/*
   ConnectionPool
   Singleton som administrerar det begr�nsade antalet uppkopplingar (ConnImpl)
   mot databasen.
*/

class ConnectionPool { // Singleton
private:
   ConnectionPool() {}

public:
   static ConnectionPool* getInstance() {
      if(inst == nullptr)
         inst = new ConnectionPool;
      return inst;
   }

   ConnImpl* acquireConnection() {
      return nullptr; // Dummy
   }

   void releaseConnection(ConnImpl* conImpl) { }

private:
   static ConnectionPool* inst;
   vector<ConnImpl> availableCon;
};

// static initialization
ConnectionPool* ConnectionPool::inst = nullptr;

//------------------------------------------------------------------------

/*
   Logisk f�rbindelse med en databas.
   En client anv�nder en DBconection f�r att st�lla en fr�ga.
   DBconnection-objektet beg�r att f� 'l�na' en ledig fysisk
   uppkoppling (acquire) fr�n poolen av tillg�ngliga uppkopplingar (ConnImpl).
   Den �terl�mnas sedan (release) till poolen och kan �teranv�ndas.
*/

class DBconnection {
public:
    DataSet* query(string qStr) {
        ConnImpl* conImpl = ConnectionPool::getInstance()->acquireConnection();
        DataSet *data = new DataSet();
        conImpl->doQuery(qStr,data);
        ConnectionPool::getInstance()->releaseConnection(conImpl);
        return data;
    }
};

//------------------------------------------------------------------------

/*
   Klienter anv�nder ett DBconnection-objekt f�r att st�lla
   en fr�ga.
*/

class Client {
public:
    DataSet* queryDB(string q) {
       return new DBconnection()->query(q);
    }
};

//------------------------------------------------------------------------

int main() {

  Client cl;
  DataSet* ds = cl.queryDB("select *");
  return 0;
}
