/*
   File:    exFacade.cpp
   Topic:   DP Facade

Subsystems:
- PointCarte, a point abstraction which uses cartesian coordinates,
  lacks ability to rotate the point around another point

- PointPolar, a Point abstraction which uses polar coordinates.
  Does have at rotate operation.

Facade:
 - Point, which combines features of the two subsystems and presents
   a unified interface. Clients (in this example class Line) can use
   Point without knowing anything about the two underlying subsystems.

 */

#include <string>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <math>
using namespace std;

class PointCarte {   // a subsystem
   public:
      PointCarte( float xx, float yy )
      :x(xx),y(yy) { }

      void move(int dx, int dy) { x += dx;  y += dy; }

      string toString() {
        ostringstream ss;
        ss << fixed << setprecision(2) << '(' << x << ',' << y << ')';
        return ss.str();
      }

      float getX() { return x; }
      float getY() { return y; }

   private:
      float x, y;
};

class PointPolar {   // another subsystem
   public:
      PointPolar(float r, float a)
      :radius(r),angle(a) { }

      void rotate(int ang)      { angle += ang % 360; }

      string toString()  {
        ostringstream ss;
        ss << '[' << radius << '@' << angle << ']';
        return ss.str();
      }

      float getRadius()   { return radius;}
      float getAngle()    { return angle;}

   private:
        float radius, angle;
};


// The Facade
class Point {
   public:
      Point(float xx, float yy)
      :pc(xx,yy) { }

      string toString() { return pc.toString(); }

      void move(int dx, int dy) { pc.move( dx,dy ); }

      void rotate( int angle, Point o ) {
         float x = pc.getX() - o.pc.getX(), y = pc.getY() - o.pc.getY();
         float ang;
         if(x==0 && y==0)
           ang=0;
         else
           ang= atan2(y,x)*180/M_PI;

         PointPolar pp( sqrt(x*x+y*y),ang );
         pp.rotate( angle );
         float r = pp.getRadius();
         float a = pp.getAngle();
         pc = PointCarte(r*cos(a*M_PI/180) + o.pc.getX(),
                          r*sin(a*M_PI/180) + o.pc.getY() );
    }

    private:
        PointCarte pc;
};


// Client which uses the Facade
class Line {
   public:
        Line( Point ori, Point end )
        :o(ori),e(end) { }

        void move( int dx, int dy ) {
           o.move(dx,dy);
           e.move(dx,dy);
        }

        void twistRoundEnd(int angle) { o.rotate(angle,e); }

        void twistRoundOrigin(int angle) { e.rotate( angle, o ); }

        void rotate( int angle ) {  // round origo
           Point origo(0,0);
           e.rotate( angle, origo );
           o.rotate( angle, origo);
        }

        string toString() {
            return "origin is " + o.toString() + ", end is " + e.toString();
        }

   private:
     Point o, e;
};

class FacadeDemo {
public:
   void run() {
      Line line1(Point(1,1),Point(2,2) );
      cout << "Before move: " + line1.toString() << endl;
      line1.move(-1,-1);
      cout << "After move (-1,-1):   " + line1.toString() << endl;
      line1.rotate(45);
      cout << "After rotate 45 degrees: " + line1.toString() << endl;
      line1.rotate(-90);
      cout << "After rotate -90 degrees: " + line1.toString() << endl;
      line1.twistRoundEnd(90);
      cout << "After twistRoundEnd 90 degrees: " + line1.toString() << endl;
      line1.twistRoundOrigin(90);
      cout << "After twistRoundOrigin 90 degrees: " + line1.toString() << endl;
   }
};

int main() {
   FacadeDemo demo;
   demo.run();
   system("pause");
   return 0;
}

/*

Before move: origin is (1.00,1.00), end is (2.00,2.00)
After move (-1,-1):   origin is (0.00,0.00), end is (1.00,1.00)
After rotate 45 degrees: origin is (0.00,0.00), end is (0.00,1.41)
After rotate -90 degrees: origin is (0.00,0.00), end is (1.41,0.00)
After twistRoundEnd 90 degrees: origin is (1.41,-1.41), end is (1.41,0.00)
After twistRoundOrigin 90 degrees: origin is (1.41,-1.41), end is (0.00,-1.41)

*/