/*
   File:        exAdapter.cpp
   Objective:   Adapter design pattern, demo of an object adapter
   Date:        2007 / �rjan Sterner

*/

#include <string>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <math>
using namespace std;

class RoundHole {
public:
   RoundHole(double d, double t)
   :diameter(d),tolerance(t)
   {
      cout << "RoundHole: diameter " << d << " tolerance " << t << endl;
   }

   double getDiameter() { return diameter; }
   double getTolerance() { return tolerance; }

private:
    double diameter, tolerance;

};

class Peg {  // Peg is the desired interface. A Peg shall fit into a RoundHole
public:
   virtual bool makeFit(RoundHole rh)=0;

};


class RoundPeg : public Peg { // A kind of a peg
public:
   RoundPeg(double d)
   :diameter(d) {}

   bool makeFit(RoundHole rh) {
      double diff = diameter - rh.getDiameter();
      cout.precision(3);
      if(diff >0 )
        cout << "Round peg with diameter " << diameter << " is too thick\n";
      else if ( fabs(diff) <= rh.getTolerance()) {
        cout << "** Round peg with diameter " << diameter << " WILL FIT.\n";
        return true;
      }
      else
        cout << "Round peg with diameter " << diameter << " is too thin\n";

      return false;

   }

private:
   double diameter;

};


class SquarePeg {  // Legacy class. Another kind of peg but with an unapropriate
                   // interface. Must be adapted!
public:
   SquarePeg( double w )
   :width(w) { }

   double getWidth()           { return width; }
   void setWidth( double w )   { width = w; }

   double getDiagonal() {
       return sqrt(2.0 * width * width);
   }

private:
   double width;
};

// Object adapter implementing the Peg interface. SquarePeg is adapted.
class SquarePegAdapter : public Peg {
public:
   SquarePegAdapter(double w)
   :sp(w)   // The adaptee
   { }


   bool makeFit(RoundHole rh) {
     // Compare the square peg diagonal with the diameter of the round hole
      double diag = sp.getDiagonal();
      double diff = diag - rh.getDiameter();
      if(diff >0 )
        cout << "Square peg with diagonal " << diag << " is too thick.\n";
      else if ( fabs(diff) <= rh.getTolerance()) {
        cout << "** Square peg with diagonal " << diag << " WILL FIT.\n";
        return true;
      }
      else
        cout << "Square peg with diagonal " << diag << " is too thin.\n";
      return false;
   }

   // The adapter "owns" an instance of the legacy class, the adaptee
   private:
      SquarePeg sp;
};

class AdapterDemo {
public:
   void run() {
      RoundHole rh(3, 0.25);
      cout << "Finding matching pegs...\n";

       // The client uses the Peg interface
      Peg *peg = NULL;
      int hits = 0;
      double x = 1.5;

      while(hits < 2 ) {
         if(peg != NULL)
            delete peg;
         peg  = new SquarePegAdapter(x); // Uses SquarePeg
         if(peg->makeFit( rh ))
           ++hits;

         peg = new RoundPeg(x);
         if(peg->makeFit(rh))
           ++hits;
         x += 0.20;
         cout << endl;
      }
   }
};

int main( ) {

      AdapterDemo demo;
      demo.run();
      system("pause");
      return 0;
}

/*

RoundHole: diameter 3.0 tolerance 0.25
Finding matching pegs...

Square peg with diagonal 2,121 is too thin.
Round peg with diameter 1,500 is too thin

Square peg with diagonal 2,404 is too thin.
Round peg with diameter 1,700 is too thin

Square peg with diagonal 2,687 is too thin.
Round peg with diameter 1,900 is too thin

** Square peg with diagonal 2,970 WILL FIT.
Round peg with diameter 2,100 is too thin

Square peg with diagonal 3,253 is too thick.
Round peg with diameter 2,300 is too thin

Square peg with diagonal 3,536 is too thick.
Round peg with diameter 2,500 is too thin

Square peg with diagonal 3,818 is too thick.
Round peg with diameter 2,700 is too thin

Square peg with diagonal 4,101 is too thick.
** Round peg with diameter 2,90 WILL FIT.

*/
